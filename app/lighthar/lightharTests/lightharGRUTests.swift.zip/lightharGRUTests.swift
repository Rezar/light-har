/**
 * Gaston Longhitano <gastonl@bu.edu> @ Boston University - Research
 *
 * This source code is licensed under the terms found in the
 * LICENSE file in the root directory of this source tree.
 */

import XCTest
import CoreML

final class lightharGRUTests: XCTestCase {

    var model: MLModel?
    var modelOutput: String?
    var range: Int64 =  10000
    
    override func setUpWithError() throws {
        model = nil
        modelOutput = "linear_24"
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        model = nil
        modelOutput = nil
    }

    func modelPredictionGRU(ttl: Double) throws {
       // XCTestExpectation allows you to wait for asynchronous code
       let expectation = self.expectation(description: "Running model for n seconds")
       
       // Set the duration to 60 seconds
       let endTime = Date().addingTimeInterval(ttl)
       
       // Prepare input data
       let inputArray = try MLMultiArray(shape: [1, 16, 3], dataType: .float32)

       // Create a background queue to simulate continuous predictions
       DispatchQueue.global().async {
           while Date() < endTime {
               // Random accelerometer readings
               for i in 0..<16 {
                   inputArray[[0, NSNumber(value: i), 0]] = NSNumber(value: Double.random(in: -1.0...1.0)) // X-axis
                   inputArray[[0, NSNumber(value: i), 1]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Y-axis
                   inputArray[[0, NSNumber(value: i), 2]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Z-axis
               }

               // Pass the input into the model
               let modelInput = GRUInput(x: inputArray) // Replace with your model's input class

               do {
                   // Make prediction
                   guard let model = self.model else {
                       XCTFail("Model failed to load.")
                       return
                   }
                   
                   let output = try model.prediction(from: modelInput)

                   // Verify the model output
                   if let outputArray = output.featureValue(for: self.modelOutput!)?.multiArrayValue {
                       var maxValue: Float = outputArray[0].floatValue
                       for i in 1..<outputArray.count {
                           let value = outputArray[i].floatValue
                           if value > maxValue {
                               maxValue = value
                           }
                       }
                       XCTAssertTrue(maxValue >= 0, "Model output should be non-negative.")
                   } else {
                       XCTFail("Failed to get model output.")
                   }
               } catch {
                   XCTFail("Error making prediction: \(error)")
               }
           }
           expectation.fulfill() // Fulfill the expectation when 60 seconds are over
       }

       // Wait for 60 seconds for the async process to complete
       waitForExpectations(timeout: 65, handler: nil) // Allow a bit more time in case of any delays
   }
    
    
    func modelPredictionGRUInt8LSQuantization(ttl: Double) throws {
       // XCTestExpectation allows you to wait for asynchronous code
       let expectation = self.expectation(description: "Running model for n seconds")
       
       // Set the duration to n seconds
       let endTime = Date().addingTimeInterval(ttl)
       
       // Prepare input data
       let inputArray = try MLMultiArray(shape: [1, 16, 3], dataType: .float32)

       // Create a background queue to simulate continuous predictions
       DispatchQueue.global().async {
           while Date() < endTime {
               // Random accelerometer readings
               for i in 0..<16 {
                   inputArray[[0, NSNumber(value: i), 0]] = NSNumber(value: Double.random(in: -1.0...1.0)) // X-axis
                   inputArray[[0, NSNumber(value: i), 1]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Y-axis
                   inputArray[[0, NSNumber(value: i), 2]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Z-axis
               }

               // Pass the input into the model
               let modelInput = GRUInt8LSQuantizationInput(x: inputArray) // Replace with your model's input class

               do {
                   // Make prediction
                   guard let model = self.model else {
                       XCTFail("Model failed to load.")
                       return
                   }
                   
                   let output = try model.prediction(from: modelInput)

                   // Verify the model output
                   if let outputArray = output.featureValue(for: self.modelOutput!)?.multiArrayValue {
                       var maxValue: Float = outputArray[0].floatValue
                       for i in 1..<outputArray.count {
                           let value = outputArray[i].floatValue
                           if value > maxValue {
                               maxValue = value
                           }
                       }
                       XCTAssertTrue(maxValue >= 0, "Model output should be non-negative.")
                   } else {
                       XCTFail("Failed to get model output.")
                   }
               } catch {
                   XCTFail("Error making prediction: \(error)")
               }
           }
           expectation.fulfill() // Fulfill the expectation when 60 seconds are over
       }

       // Wait for 60 seconds for the async process to complete
        waitForExpectations(timeout: ttl + 5.0, handler: nil) // Allow a bit more time in case of any delays
   }
    
    
    func modelPredictionGRUMagnitudePruner(ttl: Double) throws {
       // XCTestExpectation allows you to wait for asynchronous code
       let expectation = self.expectation(description: "Running model for n seconds")
       
       // Set the duration to n seconds
       let endTime = Date().addingTimeInterval(ttl)
       
       // Prepare input data
       let inputArray = try MLMultiArray(shape: [1, 16, 3], dataType: .float32)

       // Create a background queue to simulate continuous predictions
       DispatchQueue.global().async {
           while Date() < endTime {
               // Random accelerometer readings
               for i in 0..<16 {
                   inputArray[[0, NSNumber(value: i), 0]] = NSNumber(value: Double.random(in: -1.0...1.0)) // X-axis
                   inputArray[[0, NSNumber(value: i), 1]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Y-axis
                   inputArray[[0, NSNumber(value: i), 2]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Z-axis
               }

               // Pass the input into the model
               let modelInput = GRUMagnitudePrunerInput(x: inputArray)

               do {
                   // Make prediction
                   guard let model = self.model else {
                       XCTFail("Model failed to load.")
                       return
                   }
                   
                   let output = try model.prediction(from: modelInput)

                   // Verify the model output
                   if let outputArray = output.featureValue(for: self.modelOutput!)?.multiArrayValue {
                       var maxValue: Float = outputArray[0].floatValue
                       for i in 1..<outputArray.count {
                           let value = outputArray[i].floatValue
                           if value > maxValue {
                               maxValue = value
                           }
                       }
                       XCTAssertTrue(maxValue >= 0, "Model output should be non-negative.")
                   } else {
                       XCTFail("Failed to get model output.")
                   }
               } catch {
                   XCTFail("Error making prediction: \(error)")
               }
           }
           expectation.fulfill() // Fulfill the expectation when 60 seconds are over
       }

       // Wait for 60 seconds for the async process to complete
        waitForExpectations(timeout: ttl + 5.0, handler: nil) // Allow a bit more time in case of any delays
   }
    
    
    func modelPredictionGRUPalettizationLUT(ttl: Double) throws {
       // XCTestExpectation allows you to wait for asynchronous code
       let expectation = self.expectation(description: "Running model for n seconds")
       
       // Set the duration to n seconds
       let endTime = Date().addingTimeInterval(ttl)
       
       // Prepare input data
       let inputArray = try MLMultiArray(shape: [1, 16, 3], dataType: .float32)

       // Create a background queue to simulate continuous predictions
       DispatchQueue.global().async {
           while Date() < endTime {
               // Random accelerometer readings
               for i in 0..<16 {
                   inputArray[[0, NSNumber(value: i), 0]] = NSNumber(value: Double.random(in: -1.0...1.0)) // X-axis
                   inputArray[[0, NSNumber(value: i), 1]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Y-axis
                   inputArray[[0, NSNumber(value: i), 2]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Z-axis
               }

               // Pass the input into the model
               let modelInput = GRUPalettizationLUTInput(x: inputArray)

               do {
                   // Make prediction
                   guard let model = self.model else {
                       XCTFail("Model failed to load.")
                       return
                   }
                   
                   let output = try model.prediction(from: modelInput)

                   // Verify the model output
                   if let outputArray = output.featureValue(for: self.modelOutput!)?.multiArrayValue {
                       var maxValue: Float = outputArray[0].floatValue
                       for i in 1..<outputArray.count {
                           let value = outputArray[i].floatValue
                           if value > maxValue {
                               maxValue = value
                           }
                       }
                       XCTAssertTrue(maxValue >= 0, "Model output should be non-negative.")
                   } else {
                       XCTFail("Failed to get model output.")
                   }
               } catch {
                   XCTFail("Error making prediction: \(error)")
               }
           }
           expectation.fulfill() // Fulfill the expectation when 60 seconds are over
       }

       // Wait for 60 seconds for the async process to complete
        waitForExpectations(timeout: ttl + 5.0, handler: nil) // Allow a bit more time in case of any delays
   }
    
    
    func modelPredictionGRUThresholdPruner(ttl: Double) throws {
       // XCTestExpectation allows you to wait for asynchronous code
       let expectation = self.expectation(description: "Running model for n seconds")
       
       // Set the duration to n seconds
       let endTime = Date().addingTimeInterval(ttl)
       
       // Prepare input data
       let inputArray = try MLMultiArray(shape: [1, 16, 3], dataType: .float32)

       // Create a background queue to simulate continuous predictions
       DispatchQueue.global().async {
           while Date() < endTime {
               // Random accelerometer readings
               for i in 0..<16 {
                   inputArray[[0, NSNumber(value: i), 0]] = NSNumber(value: Double.random(in: -1.0...1.0)) // X-axis
                   inputArray[[0, NSNumber(value: i), 1]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Y-axis
                   inputArray[[0, NSNumber(value: i), 2]] = NSNumber(value: Double.random(in: -1.0...1.0)) // Z-axis
               }

               // Pass the input into the model
               let modelInput = GRUThresholdPrunerInput(x: inputArray) // Replace with your model's input class

               do {
                   // Make prediction
                   guard let model = self.model else {
                       XCTFail("Model failed to load.")
                       return
                   }
                   
                   let output = try model.prediction(from: modelInput)

                   // Verify the model output
                   if let outputArray = output.featureValue(for: self.modelOutput!)?.multiArrayValue {
                       var maxValue: Float = outputArray[0].floatValue
                       for i in 1..<outputArray.count {
                           let value = outputArray[i].floatValue
                           if value > maxValue {
                               maxValue = value
                           }
                       }
                       XCTAssertTrue(maxValue >= 0, "Model output should be non-negative.")
                   } else {
                       XCTFail("Failed to get model output.")
                   }
               } catch {
                   XCTFail("Error making prediction: \(error)")
               }
           }
           expectation.fulfill() // Fulfill the expectation when 60 seconds are over
       }

       // Wait for 60 seconds for the async process to complete
        waitForExpectations(timeout: ttl + 5.0, handler: nil) // Allow a bit more time in case of any delays
   }
    
    // Measure performance
    private func measurePerformance(block: @escaping () -> Void) {
        let clockMetric = XCTClockMetric()
        let memoryMetric = XCTMemoryMetric()
        let cpuMetric = XCTCPUMetric()
        
        
        // Setup the custom metrics
        let energyMetric = EnergyMetric()
        let energyConsumption = EnergyConsumptionMetric()
//        let batteryMetric = BatteryLevelMetric()
//        batteryMetric.range = range
        
        let measureOptions = XCTMeasureOptions()
        measureOptions.iterationCount = 10
        
        let metrics: [any XCTMetric] = [clockMetric, memoryMetric, cpuMetric, energyMetric, energyConsumption]
        
        measure(metrics: metrics, options: measureOptions) {
            block()
        }
    }
    
    func testGRU() {
        model = nil
        model = try? GRU().model
        measurePerformance {
            _ = try? self.modelPredictionGRU(ttl: 60)
        }
    }
    
    func testGRUInt8LSQuantization() {
        model = nil
        model = try? GRUInt8LSQuantization().model
        measurePerformance {
            _ = try? self.modelPredictionGRUInt8LSQuantization(ttl: 60)
        }
    }
    
    func testGRUMagnitudePruner() {
        model = nil
        model = try? GRUMagnitudePruner().model
        measurePerformance {
            _ = try? self.modelPredictionGRUMagnitudePruner(ttl: 60)
        }
    }
    
    func testGRUPalettizationLUT() {
        model = nil
        model = try? GRUPalettizationLUT().model
        measurePerformance {
            _ = try? self.modelPredictionGRUPalettizationLUT(ttl: 60)
        }
    }
    
    func testGRUThresholdPruner() {
        model = nil
        model = try? GRUThresholdPruner().model
        measurePerformance {
            _ = try? self.modelPredictionGRUThresholdPruner(ttl: 60)
        }
    }
}
